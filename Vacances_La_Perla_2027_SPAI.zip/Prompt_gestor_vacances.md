# Prompt mestre — Gestor de vacances La Perla

Actua com a desenvolupador d’aplicacions de planificació i crea una aplicació funcional, en català, per gestionar les vacances del personal de magatzem de La Perla. Entrega codi executable, no només un disseny o una explicació. Adjunta aquest prompt amb `dades_vacances_2027.json`, que és la llavor de dades transcrites, i opcionalment el report HTML de referència.

## Objectiu i lliurables

Una aplicació amb gestió de personal, regles, preferències, motor de planificació i botó «Crear calendari laboral». Genera una proposta de vacances explicable, un report HTML autònom i un PDF amb resum executiu i Gantt diari per persona. Presenta sempre l’estat «Esborrany», «Amb incidències» o «Validat amb les dades disponibles»; generar no equival a aprovar. No despleguis ni publiquis dades personals automàticament.

Implementa preferentment un HTML únic amb JavaScript i CSS Tailwind compilat i incrustat, funcional sense connexió ni CDN. Si l’entorn exigeix React, lliura també una versió exportada autònoma que es pugui obrir localment. No exposis claus d’API. Cap funció ha de simular èxit ni tenir botons ficticis. Per al PDF proporciona impressió amb CSS de paginació i botó que obri el diàleg real «Desar com a PDF»; si l’entorn admet generació directa, afegeix descàrrega PDF real, indicant clarament quin mecanisme s’utilitza.

## Dades i abast

Importa les 32 persones del JSON adjunt. Conserva noms, rols originals, horaris i grups. Identificadors estables independents del nom. No incorporis les persones sense grup de les fotos ni el quadre «pendent». No dedueixis horaris dels xofers: «No indicat» és desconegut, no una jornada fictícia.

Any inicial: 2027. Dies computables: dilluns a divendres, SENSE descomptar festius, per instrucció expressa. Els festius poden anotar-se visualment, però no alteren els totals en aquest mode. No consultis ni introdueixis festius automàticament. Permet configurar l’any, dies de treball i mode de festius per a futurs escenaris, mostrant sempre el criteri de còmput.

Distingir grup original i grup de vacances proposat. Mantenir els grups originals per defecte; qualsevol reagrupació ha de ser explícita, revisable i mostrar el canvi. Rols originals i habilitacions secundàries són camps diferents. «Transportista» computa com a xofer; «Mozo» com a mosso; «Auxiliares» com a auxiliar. Backups, reposicions, administració o moviments interns no compten com a auxiliars sense una habilitació expressament introduïda. No comptis una persona dues vegades per cobrir dos mínims del mateix grup sense una regla explícita que ho permeti.

## Regles confirmades i prioritat

1. Un mes sencer només pot ser febrer, abril, maig, octubre o novembre, ambdós extrems inclusius, del primer a l’últim dia del mes. No assignis mesos sencers a ningú sense selecció o preferència confirmada. El mes sencer és un període de calendari; el saldo consumit es calcula segons la modalitat de còmput configurada.
2. Qui tingui un mes sencer queda fora dels quatre grups d’estiu en aquell escenari. Qui no el tingui s’assigna exactament a un dels quatre grups.
3. Cada grup d’estiu té un bloc de dues setmanes consecutives, dilluns a divendres durant dues setmanes (10 dies computats), íntegrament dins de juliol o agost o creuant entre aquests dos mesos; cap dia fora de juliol/agost. No confondre dues setmanes amb dues setmanes independents ni exigir 14 dies computats.
4. Cada grup de vacances ha de tenir almenys 2 mossos, 2 xofers i **1 auxiliar**. El mínim inicial de 2 auxiliars ha estat corregit expressament per l’usuari a 1. No restauris el mínim de 2 des de les fotografies.
5. Com a màxim una persona amb hora de sortida 18:00 en cada grup de vacances. Aplica-ho a tots els horaris coneguts i a futurs horaris afegits. Amb horari desconegut, mostra una comprovació pendent; no afirmis validació completa d’aquesta regla.
6. Per defecte, els quatre grups fan vacances successivament, sense solapament entre grups. És un criteri de la proposta inicial, configurable, no una norma empresarial confirmada. Els membres d’un mateix grup comparteixen les dates.
7. El darrer grup d’agost no pot allargar-se al setembre.
8. Els 9 dies addicionals de la nota manuscrita queden pendents: no els assignis ni dedueixis un dret anual total. Desa la nota que indica que han de coincidir amb el mateix grup, pendent d’aclarir dates i còmput.
9. No hi ha cobertura mínima de servei confirmada ni saldos anuals confirmats. Permet configurar-los i mostra «No definit» mentre faltin; no confonguis els mínims de composició dels grups absents amb el personal que ha de romandre treballant.

La instrucció expressa de l’usuari preval sobre fotografies, notes i valors inicials. Registra la versió de les regles i la procedència. Una restricció nova no anul·la silenciosament una d’anterior.

## Escenari inicial precàrregat

G1 blau: 5–16 juliol 2027. G2 groc: 19–30 juliol 2027. G3 taronja: 2–13 agost 2027. G4 verd: 16–27 agost 2027.
8 persones per grup. Respecta les assignacions del JSON. Composició esperada:

| Grup | Mossos | Xofers | Auxiliars | Altres | Sortida 18 h coneguda |
|---|---:|---:|---:|---:|---:|
| G1 | 4 | 2 | 1 | 1 | 1 |
| G2 | 3 | 2 | 1 | 2 | 1 |
| G3 | 2 | 2 | 1 | 3 | 1 |
| G4 | 5 | 2 | 1 | 0 | 1 |

No assignis mesos complets en aquest escenari. Cada persona té 10 dies assignats; 320 dies-persona en total. No hi ha solapament entre grups. La regla de les 18 h queda pendent de confirmar per als horaris de transportistes desconeguts.

## Interfície funcional

- Tauler amb any, persones incloses, dies assignats, grups, incidències i configuració activa.
- Personal: afegir, editar i eliminar amb confirmació; activar/desactivar; cercar i filtrar per nom, rol, grup, torn i hora de sortida. Camps: ID, nom, rol original, categoria normalitzada, habilitacions, horari, grup original, participació, modalitat de vacances, mes preferit, dates sol·licitades, bloquejos i saldo opcional. Validar duplicats d’ID i camps requerits. Una exclusió ha de ser explícita i visible.
- Editor de grups i dates. Mostra recompte per rol, nombre de persones de les 18 h i conflictes en temps real.
- Regles: formulari estructurat per a les conegudes i camp de text «Afegeix una norma». Per a cada norma mostrar text original, interpretació estructurada, tipus dur/preferència, abast, prioritat i estat pendent/activa. Primer proposar la interpretació i després demanar confirmació abans d’activar-la. No executis text lliure com a codi. Sense servei d’IA, admet només patrons reconeguts o configuració manual i informa de les frases no interpretades. Mai simulis comprensió universal del llenguatge natural.
- Botó «Crear calendari laboral»: validar entrades, comprovar viabilitat, calcular, exposar incidències i presentar la proposta. Bloquejar l’etiqueta de validació si falten dades obligatòries. Permetre exportar esborranys amb la marca visible d’incidències.
- Gantt amb una fila per persona, nom, rol, torn i grup; dies numerats i dia de la setmana; caps de setmana diferenciats; colors G1–G4 i identificadors textuals; llegenda, capçalera fixa, scroll horitzontal i detall accessible en seleccionar una cel·la. Vista juliol/agost i anual per incloure mesos sencers. Diferenciar absència de calendari de dies computats.
- Desar localment amb indicació clara, recuperar estat, exportar/importar JSON complet amb versió d’esquema, validar abans de substituir dades i permetre restaurar l’escenari inicial. No confiar només en localStorage: oferir còpia JSON. Tractar tots els textos importats com a dades i escapar-los en pantalla i exports.

## Motor de càlcul

Implementa un algorisme real i determinista amb cerca amb retrocés o solver adequat. Genera blocs candidats vàlids, aplica assignacions fixades i prioritza conservar grups i dates originals; després preferències i equilibri. Usa una única funció de validació per a càlcul, edició manual i exportació. No facis només una distribució aleatòria ni codifiquis les dates inicials com a única solució.

Abans de cercar comprova recursos: quatre grups separats exigeixen almenys 8 mossos, 8 xofers i 4 auxiliars assignables i com a màxim quatre persones amb sortida 18 h coneguda. Aquesta és una condició necessària, no sempre suficient si hi ha altres restriccions. Recalcula-ho després d’excloure els mesos sencers. Actualment només hi ha 8 xofers i 4 auxiliars: si un surt de l’estiu pot esdevenir inviable. No reincorporis persones excloses, no inventis personal i no relaxis mínims per trobar una solució. Explica quin recurs falta i ofereix alternatives per revisar, mai aplicar-les silenciosament. Si s’acaba el temps de cerca, diferencia «no s’ha trobat dins del límit» d’«inviable demostrat».

Dates en ISO YYYY-MM-DD, càlcul amb dies de calendari sense errors de fus horari. Valida dates inclusives, anys de traspàs, mesos sencers i coherència de torns. Per al 2027 inicial comprova 10 dies per persona sense descompte de festius.

## Reports

Exporta HTML complet amb CSS Tailwind compilat i incrustat; sense dependències remotes, fonts externes, JavaScript extern ni imatges remotes. El report ha de ser una instantània de les dades actuals i obrir-se sense l’aplicació. No exportar només allò visible després de fer scroll.

PDF: resum executiu amb períodes, personal, criteris, canvis, recomptes per rol, solapaments i incidències. Després Gantt diari juliol/agost, amb totes les persones, noms, rols, torns i llegenda. Si hi ha mesos sencers, afegir les pàgines corresponents. A3 horitzontal per al Gantt; paginació per mes i per grups de files quan calgui, repetint capçaleres. Mai retallar persones, columnes o barres. Tipografia llegible, contrast del groc amb text fosc, nombre de pàgina, any i estat. CSS d’impressió amb colors preservats. El PDF i l’HTML han d’usar el mateix model de dades, criteris i resultats.

## Validació abans de lliurar

Demostra l’escenari inicial (32 persones, 4 grups de 8, 10 dies/persona i cap solapament entre grups). Prova eliminació d’un auxiliar o d’un xofer, canvi d’una persona a mes sencer, dues persones de les 18 h en un grup, importació invàlida, norma no interpretable i una data fora d’agost. Cal mostrar conflictes reals. Comprova que afegir i eliminar personal persisteix, que el JSON restaura l’estat, que els exports reflecteixen els canvis i que el PDF té totes les files i dies llegibles. Explica breument les limitacions reals de l’entorn i com obrir l’artefacte.
